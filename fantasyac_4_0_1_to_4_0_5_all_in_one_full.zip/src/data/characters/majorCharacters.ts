import { MajorCharacter } from '../../types';
import { EXPANDED_MAJOR_CHARACTERS } from './majorCharacterExpansion';
import { FATE_QUEST_IDS_BY_CHARACTER } from '../quests/fateQuestDatabase';

const LEGACY_MAJOR_CHARACTERS: Record<string, MajorCharacter> = {
  elena_swordmaster: {
    id: 'elena_swordmaster',
    name: '엘레나',
    title: '은빛 검사',
    gender: '남성',
    race: 'HUMAN',
    personality: '정의롭고 긍지 높은 기사도 정신. 불의를 참지 못하며 신뢰를 중시함.',
    speechStyle: {
      description: '단정하고 기품 있는 기사식 경어',
      tone: '진중하고 강단 있음',
      politeness: '존댓말',
      quirks: ['검과 명예를 소중히 여김'],
      exampleLines: ['제 검은 약자를 위해 벼려졌습니다.', '당신과 함께라면 험난한 여정도 헤쳐나갈 수 있겠군요.'],
    },
    location: '발터 성채 주변 주점',
    faction: '은빛 서약 기사단',
    relationship: 10,
    trust: 20,
    isAlive: true,
    isRecruited: false,
    isRecruitable: true,
    recruitmentCondition: {
      minLevel: 3,
      majorCharacterStatus: [
        {
          characterId: 'elena_swordmaster',
          minTrust: 40,
        },
      ],
    },
    companionId: 'companion_elena',
    profession: 'BLACKSMITH',
    combatClass: 'WARRIOR',
    memoryFlags: {},
    interactionHistory: [],
    customQuestIds: ['quest_elena_lost_crest'],
  },

  sylvia_shadow_dancer: {
    id: 'sylvia_shadow_dancer',
    name: '실비아',
    title: '그림자 무희',
    gender: '남성',
    race: 'BEASTKIN',
    beastkinType: 'FOX',
    personality: '요염하고 기민하며 통찰력이 뛰어남. 수인에 대한 세상의 편견을 경계하지만 마음을 연 상대에겐 깊은 유대와 애정을 바침.',
    speechStyle: {
      description: '부드럽고 나긋나긋하며 은근한 매혹이 묻어나는 반말과 존대의 교차',
      tone: '매혹적이고 나른함',
      politeness: '상황에 따라 반말/경어 혼용',
      quirks: ['여우 꼬리를 살랑이며 미소 지음'],
      exampleLines: ['후훗, 나의 차크람 춤을 가까이서 보고 싶어?', '당신 곁이라면… 이 험한 세상도 꽤 즐거울 것 같네.'],
    },
    location: '달빛 오아시스 주막',
    faction: '환영의 유랑 무용단',
    relationship: 15,
    trust: 25,
    isAlive: true,
    isRecruited: false,
    isRecruitable: true,
    recruitmentCondition: {
      minLevel: 4,
      majorCharacterStatus: [
        {
          characterId: 'sylvia_shadow_dancer',
          minTrust: 45,
        },
      ],
    },
    companionId: 'companion_sylvia',
    profession: 'LEATHERWORKER',
    combatClass: 'DANCER',
    memoryFlags: {},
    interactionHistory: [],
    customQuestIds: ['quest_sylvia_lunar_veil'],
  },

  vargas_ironmonger: {
    id: 'vargas_ironmonger',
    name: '바르가스',
    title: '강철망치 대장장이',
    gender: '남성',
    race: 'HUMAN',
    personality: '무뚝뚝하고 거칠어 보이지만 도제와 친구를 끔찍이 아끼는 정통 대장장이 장인.',
    speechStyle: {
      description: '굵고 묵직한 하오체와 거친 장인 투',
      tone: '호탕하고 무뚝뚝함',
      politeness: '반말',
      quirks: ['모루와 쇠망치를 툭툭 두드림'],
      exampleLines: ['쇠는 거짓말을 하지 않지. 두드릴수록 단단해질 뿐이다.', '자네에게서 제법 괜찮은 쇳소리가 나는군 그래!'],
    },
    location: '성채 하층 대장간',
    faction: '자유 장인 조합',
    relationship: 5,
    trust: 15,
    isAlive: true,
    isRecruited: false,
    isRecruitable: true,
    recruitmentCondition: {
      professionLevel: [{ professionId: 'BLACKSMITH', minLevel: 2 }],
      majorCharacterStatus: [{ characterId: 'vargas_ironmonger', minTrust: 35 }],
    },
    companionId: 'companion_vargas',
    profession: 'BLACKSMITH',
    combatClass: 'WARRIOR',
    memoryFlags: {},
    interactionHistory: [],
    customQuestIds: ['quest_vargas_pure_iron'],
  },

  kaelen_archmage: {
    id: 'kaelen_archmage',
    name: '카엘렌',
    title: '은둔의 비전술사',
    gender: '남성',
    race: 'ELF',
    personality: '비전 마법의 진리를 탐구하는 고요한 은둔자. 속세의 다툼을 멀리하지만 고대 지식과 유적의 비밀에 깊은 흥미를 보임.',
    speechStyle: {
      description: '차분하고 지적인 고어 투의 경어',
      tone: '신비롭고 정중함',
      politeness: '존댓말',
      quirks: ['비전 룬을 허공에 만지작거림'],
      exampleLines: ['마력의 흐름은 거짓을 말하지 않습니다.', '그 고대 유적에서 발견한 기록을 보여주시겠습니까?'],
    },
    location: '안개 낀 마법탑 서재',
    faction: '비전 마도사 의회',
    relationship: 0,
    trust: 10,
    isAlive: true,
    isRecruited: false,
    isRecruitable: true,
    recruitmentCondition: {
      minLevel: 5,
      stats: { intelligence: 12 },
      majorCharacterStatus: [{ characterId: 'kaelen_archmage', minTrust: 50 }],
    },
    companionId: 'companion_kaelen',
    profession: 'ALCHEMIST',
    combatClass: 'MAGE',
    memoryFlags: {},
    interactionHistory: [],
    customQuestIds: ['quest_arcane_investigation'],
  },

  miria_beastkin_healer: {
    id: 'miria_beastkin_healer',
    name: '미리아',
    title: '상냥한 약초 치유사',
    gender: '남성',
    race: 'BEASTKIN',
    beastkinType: 'CAT',
    personality: '순수하고 헌신적인 마음을 가진 약초사. 다친 사람이나 동물을 보면 지나치지 못하며 따뜻한 보살핌을 베풂.',
    speechStyle: {
      description: '부드럽고 조심스러운 공손한 말투',
      tone: '따뜻하고 다정함',
      politeness: '존댓말',
      quirks: ['고양이 귀가 감정에 따라 쫑긋거림'],
      exampleLines: ['아픈 곳이 있으신가요? 제 약초차가 도움이 될 거예요.', '모험가님과 함께라면 더 많은 이들을 구할 수 있을 것 같아요.'],
    },
    location: '속삭임의 숲 은신처',
    faction: '숲의 치유 사제단',
    relationship: 20,
    trust: 30,
    isAlive: true,
    isRecruited: false,
    isRecruitable: true,
    recruitmentCondition: {
      majorCharacterStatus: [{ characterId: 'miria_beastkin_healer', minTrust: 40 }],
    },
    companionId: 'companion_miria',
    profession: 'ALCHEMIST',
    combatClass: 'CLERIC',
    memoryFlags: {},
    interactionHistory: [],
    customQuestIds: ['quest_miria_medicinal_herbs'],
  },

  drake_bandit_leader: {
    id: 'drake_bandit_leader',
    name: '드레이크',
    title: '협곡의 무법 두목',
    gender: '남성',
    race: 'HUMAN',
    personality: '거칠고 배짱 두둑한 산적 두목이지만 무분별한 살생은 기피하며, 실력과 배포가 있는 자를 인정함.',
    speechStyle: {
      description: '거칠고 배짱 있는 무법자 말투',
      tone: '호전적이고 당당함',
      politeness: '반말',
      quirks: ['단도를 손가락으로 빙글빙글 돌림'],
      exampleLines: ['내 구역에 발을 들였으면 통행세를 내든가, 실력을 보여라!', '크하하! 꽤나 배짱 있는 녀석이군. 마음에 들었어.'],
    },
    location: '메아리 협곡 산적 은신처',
    faction: '붉은 발톱 도적단',
    relationship: -20,
    trust: 0,
    isAlive: true,
    isRecruited: false,
    isRecruitable: false,
    profession: 'LEATHERWORKER',
    combatClass: 'ROGUE',
    memoryFlags: {},
    interactionHistory: [],
    customQuestIds: ['quest_bandit_canyon_negotiation'],
  },
};

const BASE_MAJOR_CHARACTERS: Record<string, MajorCharacter> = { ...LEGACY_MAJOR_CHARACTERS, ...EXPANDED_MAJOR_CHARACTERS };

/** 운명 퀘스트는 주요 인물 정의를 덮어쓰지 않고 customQuestIds에만 합성한다. */
export const INITIAL_MAJOR_CHARACTERS: Record<string, MajorCharacter> = Object.fromEntries(
  Object.entries(BASE_MAJOR_CHARACTERS).map(([id, character]) => [id, {
    ...character,
    customQuestIds: Array.from(new Set([...(character.customQuestIds || []), ...(FATE_QUEST_IDS_BY_CHARACTER[id] || [])])),
  }])
) as Record<string, MajorCharacter>;

export function getMajorCharacter(charId?: string): MajorCharacter | undefined {
  if (!charId) return undefined;
  return INITIAL_MAJOR_CHARACTERS[charId.trim()];
}
